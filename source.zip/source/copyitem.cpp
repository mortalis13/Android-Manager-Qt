#include "copyitem.h"

CopyItem::CopyItem()
{
}
